from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(BasicDetails)
admin.site.register(PresentLocation)
admin.site.register(Status)
admin.site.register(MoneyTransfer)

